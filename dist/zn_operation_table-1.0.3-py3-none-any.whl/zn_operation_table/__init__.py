from .zn_operation_table import build_table

build_table(7, 'sum')